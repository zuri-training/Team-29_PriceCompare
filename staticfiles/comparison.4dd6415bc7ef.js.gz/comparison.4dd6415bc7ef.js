// Product Image Selector For Desktop View
function myFunction(imgs) {
  var expandImg = document.getElementById("img-Box");
  expandImg.src = imgs.src;
}
